<!DOCTYPE html>
<html lang="en">
<?php 
include '../constants/settings.php';
include './constants/check-login.php';

if (isset($_GET['id'])) {
    require '../constants/db_config.php';
    $job_id = $_GET['id'];
    
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Get job details
        $stmt = $conn->prepare("SELECT j.*, u.first_name as company_name, u.email as company_email 
                               FROM tbl_jobs j 
                               LEFT JOIN tbl_users u ON j.company = u.member_no 
                               WHERE j.job_id = :id");
        $stmt->bindParam(':id', $job_id);
        $stmt->execute();
        $job = $stmt->fetch(PDO::FETCH_ASSOC);

        // Get application count
        $stmt = $conn->prepare("SELECT COUNT(*) as app_count FROM tbl_job_applications WHERE job_id = :id");
        $stmt->bindParam(':id', $job_id);
        $stmt->execute();
        $app_count = $stmt->fetch(PDO::FETCH_ASSOC)['app_count'];

    } catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
    }
}
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Job Details - <?php echo htmlspecialchars($job['title']); ?></title>
    <link rel="shortcut icon" href="../images/ico/favicon.png">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/admin.css" rel="stylesheet">
    <link rel="stylesheet" href="../icons/font-awesome/css/font-awesome.min.css">
    <style>
        .job-header {
            background: linear-gradient(135deg, #2c3e50 0%, #e74c3c 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .job-header h2 {
            margin: 0;
            font-size: 24px;
        }

        .job-header p {
            margin: 5px 0 0;
            opacity: 0.8;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card i {
            font-size: 40px;
            margin-bottom: 10px;
            color: #e74c3c;
        }

        .stat-card h3 {
            margin: 0;
            font-size: 28px;
            color: #2c3e50;
        }

        .stat-card p {
            margin: 5px 0 0;
            color: #7f8c8d;
        }

        .info-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .info-section h3 {
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e74c3c;
        }

        .info-item {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }

        .info-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .info-label {
            color: #7f8c8d;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .info-value {
            color: #2c3e50;
            font-size: 16px;
        }

        .action-buttons {
            margin-top: 20px;
        }

        .action-buttons .btn {
            margin-right: 10px;
            padding: 8px 20px;
        }

        .requirements-list {
            list-style-type: none;
            padding: 0;
        }

        .requirements-list li {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }

        .requirements-list li:last-child {
            border-bottom: none;
        }

        .requirements-list li i {
            color: #e74c3c;
            margin-right: 10px;
        }

        .status-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: bold;
        }

        .status-active {
            background: #2ecc71;
            color: white;
        }

        .status-inactive {
            background: #e74c3c;
            color: white;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .animate-fade-in {
            animation: fadeIn 0.5s ease-out forwards;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <?php include 'constants/sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <?php if (isset($job) && $job): ?>
            <!-- Job Header -->
            <div class="job-header animate-fade-in">
                <div class="row">
                    <div class="col-md-8">
                        <h2><i class="fa fa-briefcase"></i> <?php echo htmlspecialchars($job['title']); ?></h2>
                        <p>
                            <i class="fa fa-building"></i> <?php echo htmlspecialchars($job['company_name']); ?> |
                            <i class="fa fa-map-marker"></i> <?php echo htmlspecialchars($job['country'] . ', ' . $job['city']); ?>
                        </p>
                    </div>
                    <div class="col-md-4 text-right">
                        <div class="action-buttons">
                            <button class="btn btn-primary" data-toggle="modal" data-target="#editJob<?php echo $job['job_id']; ?>">
                                <i class="fa fa-edit"></i> Edit
                            </button>
                            <a href="app/delete-job.php?id=<?php echo $job['job_id']; ?>" 
                               class="btn btn-danger"
                               onclick="return confirm('Are you sure you want to delete this job?')">
                                <i class="fa fa-trash"></i> Delete
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Statistics -->
            <div class="row animate-fade-in" style="animation-delay: 0.2s;">
                <div class="col-md-3">
                    <div class="stat-card text-center">
                        <i class="fa fa-file-text"></i>
                        <h3><?php echo $app_count; ?></h3>
                        <p>Applications</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card text-center">
                        <i class="fa fa-calendar"></i>
                        <h3><?php echo date('M d', strtotime($job['closing_date'])); ?></h3>
                        <p>Closing Date</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card text-center">
                        <i class="fa fa-money"></i>
                        <h3><?php echo htmlspecialchars($job['salary']); ?></h3>
                        <p>Salary Range</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card text-center">
                        <i class="fa fa-clock-o"></i>
                        <h3><?php echo htmlspecialchars($job['type']); ?></h3>
                        <p>Job Type</p>
                    </div>
                </div>
            </div>

            <!-- Job Details -->
            <div class="row">
                <div class="col-md-8">
                    <div class="info-section animate-fade-in" style="animation-delay: 0.4s;">
                        <h3><i class="fa fa-info-circle"></i> Job Description</h3>
                        <div class="info-item">
                            <div class="info-value">
                                <?php echo nl2br(htmlspecialchars($job['description'])); ?>
                            </div>
                        </div>
                    </div>

                    <div class="info-section animate-fade-in" style="animation-delay: 0.6s;">
                        <h3><i class="fa fa-list"></i> Requirements</h3>
                        <ul class="requirements-list">
                            <?php
                            $requirements = explode("\n", $job['requirements']);
                            foreach ($requirements as $requirement) {
                                if (!empty(trim($requirement))) {
                                    echo '<li><i class="fa fa-check-circle"></i> ' . htmlspecialchars(trim($requirement)) . '</li>';
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="info-section animate-fade-in" style="animation-delay: 0.4s;">
                        <h3><i class="fa fa-cog"></i> Job Details</h3>
                        <div class="info-item">
                            <div class="info-label">Status</div>
                            <div class="info-value">
                                <span class="status-badge <?php echo time() < strtotime($job['closing_date']) ? 'status-active' : 'status-inactive'; ?>">
                                    <?php echo time() < strtotime($job['closing_date']) ? 'Active' : 'Closed'; ?>
                                </span>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Experience</div>
                            <div class="info-value"><?php echo htmlspecialchars($job['experience']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Posted Date</div>
                            <div class="info-value"><?php echo date('F d, Y', strtotime($job['date_posted'])); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Closing Date</div>
                            <div class="info-value"><?php echo date('F d, Y', strtotime($job['closing_date'])); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Vacancy</div>
                            <div class="info-value"><?php echo htmlspecialchars($job['vacancy']); ?> Position(s)</div>
                        </div>
                    </div>

                    <div class="info-section animate-fade-in" style="animation-delay: 0.6s;">
                        <h3><i class="fa fa-building"></i> Company Info</h3>
                        <div class="info-item">
                            <div class="info-label">Company Name</div>
                            <div class="info-value"><?php echo htmlspecialchars($job['company_name']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Email</div>
                            <div class="info-value"><?php echo htmlspecialchars($job['company_email']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Location</div>
                            <div class="info-value">
                                <?php echo htmlspecialchars($job['country'] . ', ' . $job['city']); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Edit Modal -->
            <div class="modal fade" id="editJob<?php echo $job['job_id']; ?>" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Edit Job Details</h4>
                        </div>
                        <form action="app/update-job.php" method="post">
                            <div class="modal-body">
                                <input type="hidden" name="job_id" value="<?php echo $job['job_id']; ?>">
                                
                                <div class="form-group">
                                    <label>Job Title</label>
                                    <input type="text" class="form-control" name="title" 
                                           value="<?php echo htmlspecialchars($job['title']); ?>" required>
                                </div>
                                
                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea class="form-control" name="description" rows="5" required><?php 
                                        echo htmlspecialchars($job['description']); 
                                    ?></textarea>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Salary Range</label>
                                            <input type="text" class="form-control" name="salary" 
                                                   value="<?php echo htmlspecialchars($job['salary']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Job Type</label>
                                            <select class="form-control" name="type">
                                                <option value="Full-time" <?php if($job['type'] == 'Full-time') echo 'selected'; ?>>Full-time</option>
                                                <option value="Part-time" <?php if($job['type'] == 'Part-time') echo 'selected'; ?>>Part-time</option>
                                                <option value="Contract" <?php if($job['type'] == 'Contract') echo 'selected'; ?>>Contract</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Experience Required</label>
                                            <input type="text" class="form-control" name="experience" 
                                                   value="<?php echo htmlspecialchars($job['experience']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Vacancy</label>
                                            <input type="number" class="form-control" name="vacancy" 
                                                   value="<?php echo htmlspecialchars($job['vacancy']); ?>">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label>Requirements</label>
                                    <textarea class="form-control" name="requirements" rows="5"><?php 
                                        echo htmlspecialchars($job['requirements']); 
                                    ?></textarea>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Country</label>
                                            <input type="text" class="form-control" name="country" 
                                                   value="<?php echo htmlspecialchars($job['country']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>City</label>
                                            <input type="text" class="form-control" name="city" 
                                                   value="<?php echo htmlspecialchars($job['city']); ?>">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label>Closing Date</label>
                                    <input type="date" class="form-control" name="closing_date" 
                                           value="<?php echo date('Y-m-d', strtotime($job['closing_date'])); ?>">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        <?php else: ?>
            <div class="alert alert-danger">
                <strong>Error!</strong> Job not found.
            </div>
        <?php endif; ?>
    </div>

    <script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="../js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
</body>
</html> 