<!DOCTYPE html>
<html lang="en">
<?php 
include '../constants/settings.php';
include './constants/check-login.php';
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nightingale Jobs - Admin Dashboard</title>
    <link rel="shortcut icon" href="../images/ico/favicon.png">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/admin.css" rel="stylesheet">
    <link rel="stylesheet" href="../icons/font-awesome/css/font-awesome.min.css">
    <style>
        /* Keyframes for animations */
        @keyframes slideIn {
            from {
                transform: translateX(-100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes scaleIn {
            from {
                transform: scale(0.8);
                opacity: 0;
            }
            to {
                transform: scale(1);
                opacity: 1;
            }
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
            100% {
                transform: scale(1);
            }
        }

        /* Apply animations to elements */
        .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding: 20px;
            background: #2c3e50;
            color: white;
            width: 250px;
            animation: slideIn 0.5s ease-out;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            animation: fadeIn 0.5s ease-out;
        }

        .sidebar-header {
            padding: 20px 0;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-menu {
            margin-top: 30px;
        }

        .sidebar-menu a {
            color: white;
            padding: 12px 20px;
            display: block;
            transition: all 0.3s ease;
            text-decoration: none;
            position: relative;
            overflow: hidden;
        }

        .sidebar-menu a:before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 0;
            background: rgba(255,255,255,0.1);
            transition: width 0.3s ease;
        }

        .sidebar-menu a:hover:before {
            width: 100%;
        }

        .sidebar-menu i {
            margin-right: 10px;
            transition: transform 0.3s ease;
        }

        .sidebar-menu a:hover i {
            transform: scale(1.2);
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            transition: all 0.3s ease;
            animation: scaleIn 0.5s ease-out;
            cursor: pointer;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .stat-card h3 {
            margin: 0;
            color: #2c3e50;
        }

        .stat-card p {
            margin: 5px 0 0;
            color: #7f8c8d;
        }

        .stat-card i {
            transition: transform 0.3s ease;
        }

        .stat-card:hover i {
            animation: pulse 1s infinite;
        }

        .top-header {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            animation: fadeIn 0.5s ease-out;
        }

        .user-profile {
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
        }

        .user-profile:hover {
            transform: scale(1.05);
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            transition: all 0.3s ease;
        }

        .user-profile:hover img {
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
        }

        .panel {
            animation: fadeIn 0.5s ease-out;
            transition: all 0.3s ease;
        }

        .panel:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .table-responsive {
            animation: fadeIn 0.5s ease-out;
        }

        .table tr {
            transition: all 0.3s ease;
        }

        .table tr:hover {
            transform: scale(1.01);
            background-color: #f8f9fa;
        }

        /* Staggered animation for stat cards */
        .stat-card:nth-child(1) { animation-delay: 0.1s; }
        .stat-card:nth-child(2) { animation-delay: 0.2s; }
        .stat-card:nth-child(3) { animation-delay: 0.3s; }
        .stat-card:nth-child(4) { animation-delay: 0.4s; }

        /* Active menu item highlight */
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            border-left: 4px solid #3498db;
        }

        /* Smooth page transitions */
        body {
            opacity: 0;
            animation: fadeIn 0.5s ease-out forwards;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <img src="../images/logo.png" alt="Logo" style="max-height: 50px;">
            <h4 style="margin-top: 15px;">Admin Dashboard</h4>
        </div>
        <div class="sidebar-menu">
            <a href="index.php" class="active"><i class="fa fa-dashboard"></i> Dashboard</a>
            <a href="employers.php"><i class="fa fa-building"></i> Employers</a>
            <a href="employees.php"><i class="fa fa-users"></i> Job Seekers</a>
            <a href="applications.php"><i class="fa fa-file-text"></i> Applications</a>
            <a href="settings.php"><i class="fa fa-cog"></i> Settings</a>
            <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <h2>Welcome, Admin!</h2>
            <div class="user-profile">
                <img src="../images/admin.jpg" alt="Admin">
                <div>
                    <strong>Admin User</strong>
                    <small>Administrator</small>
                </div>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="row">
            <div class="col-md-3">
                <div class="stat-card">
                    <i class="fa fa-building fa-3x" style="color: #3498db;"></i>
                    <h3>
                        <?php
                        require '../constants/db_config.php';
                        try {
                            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                            $stmt = $conn->prepare("SELECT COUNT(*) FROM tbl_users WHERE role = 'employer'");
                            $stmt->execute();
                            $result = $stmt->fetchColumn();
                            echo $result;
                        } catch(PDOException $e) {
                            echo "0";
                        }
                        ?>
                    </h3>
                    <p>Total Employers</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <i class="fa fa-users fa-3x" style="color: #2ecc71;"></i>
                    <h3>
                        <?php
                        try {
                            $stmt = $conn->prepare("SELECT COUNT(*) FROM tbl_users WHERE role = 'employee'");
                            $stmt->execute();
                            $result = $stmt->fetchColumn();
                            echo $result;
                        } catch(PDOException $e) {
                            echo "0";
                        }
                        ?>
                    </h3>
                    <p>Total Job Seekers</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <i class="fa fa-briefcase fa-3x" style="color: #e74c3c;"></i>
                    <h3>
                        <?php
                        try {
                            $stmt = $conn->prepare("SELECT COUNT(*) FROM tbl_jobs");
                            $stmt->execute();
                            $result = $stmt->fetchColumn();
                            echo $result;
                        } catch(PDOException $e) {
                            echo "0";
                        }
                        ?>
                    </h3>
                    <p>Active Jobs</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <i class="fa fa-file-text fa-3x" style="color: #f39c12;"></i>
                    <h3>
                        <?php
                        try {
                            $stmt = $conn->prepare("SELECT COUNT(*) FROM tbl_job_applications");
                            $stmt->execute();
                            $result = $stmt->fetchColumn();
                            echo $result;
                        } catch(PDOException $e) {
                            echo "0";
                        }
                        ?>
                    </h3>
                    <p>Total Applications</p>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="row" style="margin-top: 30px;">
            <div class="col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Recent Employers</h3>
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Company</th>
                                        <th>Email</th>
                                        <th>Date Registered</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    try {
                                        $stmt = $conn->prepare("SELECT * FROM tbl_users WHERE role = 'employer' ORDER BY member_no DESC LIMIT 5");
                                        $stmt->execute();
                                        $results = $stmt->fetchAll();
                                        foreach($results as $row) {
                                            echo '<tr>';
                                            echo '<td>'.htmlspecialchars($row['first_name']).'</td>';
                                            echo '<td>'.htmlspecialchars($row['email']).'</td>';
                                            echo '<td>'.(!empty($row['date_registered']) ? date("d M Y", strtotime($row['date_registered'])) : 'N/A').'</td>';
                                            echo '</tr>';
                                        }
                                    } catch(PDOException $e) {
                                        echo '<tr><td colspan="3">No data available</td></tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Recent Job Seekers</h3>
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Date Registered</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    try {
                                        $stmt = $conn->prepare("SELECT * FROM tbl_users WHERE role = 'employee' ORDER BY member_no DESC LIMIT 5");
                                        $stmt->execute();
                                        $results = $stmt->fetchAll();
                                        foreach($results as $row) {
                                            echo '<tr>';
                                            echo '<td>'.htmlspecialchars($row['first_name'].' '.$row['last_name']).'</td>';
                                            echo '<td>'.htmlspecialchars($row['email']).'</td>';
                                            echo '<td>'.(!empty($row['date_registered']) ? date("d M Y", strtotime($row['date_registered'])) : 'N/A').'</td>';
                                            echo '</tr>';
                                        }
                                    } catch(PDOException $e) {
                                        echo '<tr><td colspan="3">No data available</td></tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="../js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
</body>
</html> 