<?php
require '../../constants/db_config.php';
session_start();

if (isset($_GET['id'])) {
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Start transaction
        $conn->beginTransaction();
        
        // First get all job IDs posted by this employer
        $stmt = $conn->prepare("SELECT job_id FROM tbl_jobs WHERE company = :id");
        $stmt->bindParam(':id', $_GET['id']);
        $stmt->execute();
        $job_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (!empty($job_ids)) {
            // Delete all job applications for these jobs
            $placeholders = str_repeat('?,', count($job_ids) - 1) . '?';
            $stmt = $conn->prepare("DELETE FROM tbl_job_applications WHERE job_id IN ($placeholders)");
            $stmt->execute($job_ids);
            
            // Delete all jobs posted by this employer
            $stmt = $conn->prepare("DELETE FROM tbl_jobs WHERE company = :id");
            $stmt->bindParam(':id', $_GET['id']);
            $stmt->execute();
        }
        
        // Delete the employer
        $stmt = $conn->prepare("DELETE FROM tbl_users WHERE member_no = :id AND role = 'employer'");
        $stmt->bindParam(':id', $_GET['id']);
        $stmt->execute();
        
        // Commit transaction
        $conn->commit();
        
        $_SESSION['success_msg'] = "Employer and all related jobs have been deleted successfully";
    } catch(PDOException $e) {
        // Rollback transaction on error
        $conn->rollBack();
        $_SESSION['error_msg'] = "Error deleting employer: " . $e->getMessage();
    }
}

header("Location: ../settings.php");
exit();
?> 