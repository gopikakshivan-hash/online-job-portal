<?php
include '../../constants/db_config.php';

if (isset($_POST['member_no'])) {
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $stmt = $conn->prepare("SELECT * FROM tbl_users WHERE member_no = :member_no AND role = 'employee'");
        $stmt->bindParam(':member_no', $_POST['member_no']);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo json_encode($result);
    } catch(PDOException $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
} 