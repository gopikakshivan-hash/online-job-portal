<?php
require '../../constants/db_config.php';
session_start();

if (isset($_GET['id'])) {
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Start transaction
        $conn->beginTransaction();
        
        // Delete all job applications by this job seeker
        $stmt = $conn->prepare("DELETE FROM tbl_job_applications WHERE member_no = :id");
        $stmt->bindParam(':id', $_GET['id']);
        $stmt->execute();
        
        // Delete the job seeker
        $stmt = $conn->prepare("DELETE FROM tbl_users WHERE member_no = :id AND role = 'employee'");
        $stmt->bindParam(':id', $_GET['id']);
        $stmt->execute();
        
        // Commit transaction
        $conn->commit();
        
        $_SESSION['success_msg'] = "Job seeker deleted successfully";
    } catch(PDOException $e) {
        // Rollback transaction on error
        $conn->rollBack();
        $_SESSION['error_msg'] = "Error deleting job seeker: " . $e->getMessage();
    }
}

header("Location: ../settings.php");
exit();
?> 