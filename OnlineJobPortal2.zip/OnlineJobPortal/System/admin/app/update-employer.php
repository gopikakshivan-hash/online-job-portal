<?php
include '../../constants/db_config.php';
session_start();

if (isset($_POST['member_no'])) {
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $stmt = $conn->prepare("UPDATE tbl_users SET 
            first_name = :company_name,
            email = :email,
            phone = :phone,
            country = :country,
            city = :city
            WHERE member_no = :member_no AND role = 'employer'");
            
        $stmt->bindParam(':company_name', $_POST['company_name']);
        $stmt->bindParam(':email', $_POST['email']);
        $stmt->bindParam(':phone', $_POST['phone']);
        $stmt->bindParam(':country', $_POST['country']);
        $stmt->bindParam(':city', $_POST['city']);
        $stmt->bindParam(':member_no', $_POST['member_no']);
        
        $stmt->execute();
        
        $_SESSION['success'] = "Employer details updated successfully";
    } catch(PDOException $e) {
        $_SESSION['error'] = "Error updating employer: " . $e->getMessage();
    }
}

header("Location: ../settings.php"); 