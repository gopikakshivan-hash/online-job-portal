<?php
require '../../constants/db_config.php';
session_start();

if (isset($_GET['id'])) {
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Delete the application
        $stmt = $conn->prepare("DELETE FROM tbl_job_applications WHERE id = :id");
        $stmt->bindParam(':id', $_GET['id']);
        $stmt->execute();
        
        $_SESSION['success_msg'] = "Application deleted successfully";
    } catch(PDOException $e) {
        $_SESSION['error_msg'] = "Error deleting application: " . $e->getMessage();
    }
}

header("Location: ../applications.php");
exit();
?> 