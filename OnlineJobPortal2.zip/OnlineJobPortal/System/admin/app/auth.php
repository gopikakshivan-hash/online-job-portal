<?php
require '../../constants/db_config.php';
session_start();

if(isset($_POST['username']) && isset($_POST['password'])) {
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $conn->prepare("SELECT * FROM tbl_admin WHERE username = :username");
        $stmt->bindParam(':username', $_POST['username']);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $rec = count($result);
        
        if($rec > 0) {
            foreach($result as $row) {
                $admin_id = $row['admin_id'];
                $hashed_password = $row['password'];
                
                if(password_verify($_POST['password'], $hashed_password)) {
                    $_SESSION['admin_logged'] = true;
                    $_SESSION['admin_id'] = $admin_id;
                    $_SESSION['admin_username'] = $row['username'];
                    $_SESSION['admin_fullname'] = $row['fullname'];
                    $_SESSION['admin_role'] = $row['role'];
                    
                    // Update last login
                    $last_login = date('Y-m-d H:i:s');
                    $stmt = $conn->prepare("UPDATE tbl_admin SET last_login = :last_login WHERE admin_id = :admin_id");
                    $stmt->bindParam(':last_login', $last_login);
                    $stmt->bindParam(':admin_id', $admin_id);
                    $stmt->execute();
                    
                    header("location:../index.php");
                    exit();
                } else {
                    header("location:../login.php?r=invalid");
                    exit();
                }
            }
        } else {
            header("location:../login.php?r=invalid");
            exit();
        }
    } catch(PDOException $e) {
        header("location:../login.php?r=error");
        exit();
    }
} else {
    header("location:../login.php");
    exit();
}
?> 