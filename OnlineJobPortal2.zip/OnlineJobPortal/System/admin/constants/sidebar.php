<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<style>
.sidebar {
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    padding: 20px;
    background: #2c3e50;
    color: white;
    width: 250px;
    z-index: 1000;
}

.sidebar-header {
    text-align: center;
    padding-bottom: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.sidebar-menu {
    margin-top: 30px;
}

.sidebar-menu a {
    color: white;
    padding: 12px 20px;
    display: block;
    text-decoration: none;
    transition: all 0.3s ease;
    opacity: 0.8;
}

.sidebar-menu a:hover {
    background: rgba(255,255,255,0.1);
    opacity: 1;
    padding-left: 25px;
}

.sidebar-menu a.active {
    background: rgba(255,255,255,0.1);
    border-left: 4px solid #3498db;
    opacity: 1;
}

.sidebar-menu i {
    margin-right: 10px;
    width: 20px;
    text-align: center;
}
</style>

<div class="sidebar">
    <div class="sidebar-header">
        <img src="../images/logo.png" alt="Logo" style="max-height: 50px;">
        <h4 style="margin-top: 15px;">Admin Dashboard</h4>
    </div>
    <div class="sidebar-menu">
        <a href="index.php" <?php if($current_page == 'index.php') echo 'class="active"'; ?>>
            <i class="fa fa-dashboard"></i> Dashboard
        </a>
        <a href="employers.php" <?php if($current_page == 'employers.php') echo 'class="active"'; ?>>
            <i class="fa fa-building"></i> Employers
        </a>
        <a href="employees.php" <?php if($current_page == 'employees.php') echo 'class="active"'; ?>>
            <i class="fa fa-users"></i> Job Seekers
        </a>
        <a href="applications.php" <?php if($current_page == 'applications.php') echo 'class="active"'; ?>>
            <i class="fa fa-file-text"></i> Applications
        </a>
        <a href="settings.php" <?php if($current_page == 'settings.php') echo 'class="active"'; ?>>
            <i class="fa fa-cog"></i> Settings
        </a>
        <a href="logout.php">
            <i class="fa fa-sign-out"></i> Logout
        </a>
    </div>
</div> 