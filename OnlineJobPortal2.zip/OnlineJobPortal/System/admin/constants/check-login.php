<?php
session_start();

if(!isset($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header("location: login.php?r=1");
    exit;
}
?> 