<!DOCTYPE html>
<html lang="en">
<?php 
include '../constants/settings.php';
include './constants/check-login.php';

if (isset($_GET['id'])) {
    require '../constants/db_config.php';
    $employer_id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT); // Sanitize input
    
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Get employer details with additional company information
        $stmt = $conn->prepare("SELECT u.*, 
            (SELECT COUNT(*) FROM tbl_jobs WHERE company = :id1) as job_count,
            (SELECT COUNT(*) FROM tbl_job_applications WHERE company = :id2) as app_count
            FROM tbl_users u 
            WHERE u.member_no = :id3 AND u.role = 'employer'");
        
        $stmt->bindParam(':id1', $employer_id);
        $stmt->bindParam(':id2', $employer_id);
        $stmt->bindParam(':id3', $employer_id);
        $stmt->execute();
        $employer = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$employer) {
            $_SESSION['error'] = "Employer not found!";
            header("Location: employers.php");
            exit;
        }

    } catch(PDOException $e) {
        error_log("Error in view-employer.php: " . $e->getMessage());
        $_SESSION['error'] = "An error occurred while fetching employer details.";
        header("Location: employers.php");
        exit;
    }
} else {
    $_SESSION['error'] = "Invalid request!";
    header("Location: employers.php");
    exit;
}

// Get recent job postings
try {
    $stmt = $conn->prepare("SELECT * FROM tbl_jobs WHERE company = :id ORDER BY closing_date DESC LIMIT 5");
    $stmt->bindParam(':id', $employer_id);
    $stmt->execute();
    $recent_jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    error_log("Error fetching recent jobs: " . $e->getMessage());
    $recent_jobs = [];
}
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Employer Details - <?php echo htmlspecialchars($employer['first_name']); ?></title>
    <link rel="shortcut icon" href="../images/ico/favicon.png">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/admin.css" rel="stylesheet">
    <link rel="stylesheet" href="../icons/font-awesome/css/font-awesome.min.css">
    <style>
        .profile-header {
            background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
            color: white;
            padding: 40px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
            position: relative;
            overflow: hidden;
        }

        .profile-header::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: linear-gradient(45deg, rgba(52, 152, 219, 0.3) 0%, rgba(52, 152, 219, 0) 70%);
        }

        .profile-header h2 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
            text-shadow: 0 2px 4px rgba(0,0,0,0.2);
            position: relative;
        }

        .profile-header p {
            margin: 10px 0 0;
            opacity: 0.9;
            font-size: 16px;
            position: relative;
        }

        .profile-header i {
            margin-right: 10px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border: 1px solid rgba(0,0,0,0.05);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            border-color: #3498db;
        }

        .stat-card i {
            font-size: 45px;
            margin-bottom: 15px;
            color: #3498db;
            background: rgba(52, 152, 219, 0.1);
            padding: 15px;
            border-radius: 50%;
            transition: all 0.3s ease;
        }

        .stat-card:hover i {
            transform: scale(1.1);
            background: rgba(52, 152, 219, 0.2);
        }

        .stat-card h3 {
            margin: 0;
            font-size: 32px;
            font-weight: 600;
            color: #2c3e50;
        }

        .stat-card p {
            margin: 10px 0 0;
            color: #7f8c8d;
            font-size: 16px;
            font-weight: 500;
        }

        .info-section {
            background: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border: 1px solid rgba(0,0,0,0.05);
            transition: all 0.3s ease;
        }

        .info-section:hover {
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            border-color: #3498db;
        }

        .info-section h3 {
            color: #2c3e50;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #3498db;
            font-size: 22px;
            font-weight: 600;
            display: flex;
            align-items: center;
        }

        .info-section h3 i {
            margin-right: 10px;
            color: #3498db;
            font-size: 24px;
        }

        .info-item {
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
            transition: all 0.3s ease;
        }

        .info-item:hover {
            background: rgba(52, 152, 219, 0.05);
            padding: 15px;
            border-radius: 10px;
            margin: -15px -15px 20px -15px;
        }

        .info-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .info-label {
            color: #7f8c8d;
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .info-value {
            color: #2c3e50;
            font-size: 16px;
            line-height: 1.6;
        }

        .info-value a {
            color: #3498db;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .info-value a:hover {
            color: #2980b9;
            text-decoration: underline;
        }

        .action-buttons {
            margin-top: 20px;
        }

        .action-buttons .btn {
            margin-right: 10px;
            padding: 10px 25px;
            border-radius: 8px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }

        .action-buttons .btn-primary {
            background: #3498db;
            border-color: #3498db;
        }

        .action-buttons .btn-primary:hover {
            background: #2980b9;
            border-color: #2980b9;
            transform: translateY(-2px);
        }

        .action-buttons .btn-danger {
            background: #e74c3c;
            border-color: #e74c3c;
        }

        .action-buttons .btn-danger:hover {
            background: #c0392b;
            border-color: #c0392b;
            transform: translateY(-2px);
        }

        .map-container {
            height: 300px;
            border-radius: 15px;
            overflow: hidden;
            margin-top: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border: 1px solid rgba(0,0,0,0.05);
            transition: all 0.3s ease;
        }

        .map-container:hover {
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .map-placeholder {
            height: 100%;
            background: linear-gradient(135deg, #f5f7fa 0%, #eef2f7 100%);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #95a5a6;
        }

        .map-placeholder i {
            font-size: 48px;
            margin-bottom: 15px;
            color: #bdc3c7;
        }

        .modal-content {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .modal-header {
            background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
            color: white;
            border-radius: 15px 15px 0 0;
            padding: 20px 30px;
        }

        .modal-title {
            font-size: 20px;
            font-weight: 600;
        }

        .modal-body {
            padding: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-control {
            height: 45px;
            border-radius: 8px;
            border: 2px solid #eef2f7;
            padding: 10px 15px;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: #3498db;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
        }

        .modal-footer {
            padding: 20px 30px;
            border-top: 1px solid #eef2f7;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .animate-fade-in {
            animation: fadeIn 0.5s ease-out forwards;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .profile-header {
                padding: 30px;
            }

            .stat-card {
                margin-bottom: 20px;
            }

            .action-buttons .btn {
                display: block;
                width: 100%;
                margin-bottom: 10px;
            }
        }

        .label {
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .label-success {
            background: #2ecc71;
            color: white;
        }
        
        .label-danger {
            background: #e74c3c;
            color: white;
        }

        .info-section .row {
            margin-left: -15px;
            margin-right: -15px;
        }

        .alert {
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            border: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .alert-danger {
            background: #fee;
            color: #e74c3c;
        }

        .alert strong {
            font-weight: 600;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <?php include 'constants/sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <?php if (isset($employer) && $employer): ?>
            <!-- Profile Header -->
            <div class="profile-header animate-fade-in">
                <div class="row">
                    <div class="col-md-8">
                        <h2><i class="fa fa-building"></i> <?php echo htmlspecialchars($employer['first_name']); ?></h2>
                        <p><i class="fa fa-envelope"></i> <?php echo htmlspecialchars($employer['email']); ?></p>
                    </div>
                    <div class="col-md-4 text-right">
                        <div class="action-buttons">
                            <button class="btn btn-primary" data-toggle="modal" data-target="#editEmployer<?php echo $employer['member_no']; ?>">
                                <i class="fa fa-edit"></i> Edit
                            </button>
                            <a href="app/delete-employer.php?id=<?php echo $employer['member_no']; ?>" 
                               class="btn btn-danger"
                               onclick="return confirm('Are you sure you want to delete this employer?')">
                                <i class="fa fa-trash"></i> Delete
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Statistics -->
            <div class="row animate-fade-in" style="animation-delay: 0.2s;">
                <div class="col-md-4">
                    <div class="stat-card text-center">
                        <i class="fa fa-briefcase"></i>
                        <h3><?php echo $employer['job_count']; ?></h3>
                        <p>Posted Jobs</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card text-center">
                        <i class="fa fa-file-text"></i>
                        <h3><?php echo $employer['app_count']; ?></h3>
                        <p>Total Applications</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card text-center">
                        <i class="fa fa-calendar"></i>
                        <h3><?php echo date('M Y', strtotime($employer['date_registered'])); ?></h3>
                        <p>Member Since</p>
                    </div>
                </div>
            </div>

            <!-- Company Information -->
            <div class="row">
                <div class="col-md-6">
                    <div class="info-section animate-fade-in" style="animation-delay: 0.4s;">
                        <h3><i class="fa fa-info-circle"></i> Company Information</h3>
                        <div class="info-item">
                            <div class="info-label">Company Name</div>
                            <div class="info-value"><?php echo htmlspecialchars($employer['first_name']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Email Address</div>
                            <div class="info-value"><?php echo htmlspecialchars($employer['email']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Phone Number</div>
                            <div class="info-value"><?php echo htmlspecialchars($employer['phone']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Website</div>
                            <div class="info-value">
                                <?php echo !empty($employer['website']) ? 
                                    '<a href="'.htmlspecialchars($employer['website']).'" target="_blank">'.
                                    htmlspecialchars($employer['website']).'</a>' : 'Not specified'; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="info-section animate-fade-in" style="animation-delay: 0.6s;">
                        <h3><i class="fa fa-map-marker"></i> Location Information</h3>
                        <div class="info-item">
                            <div class="info-label">Country</div>
                            <div class="info-value"><?php echo htmlspecialchars($employer['country']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">City</div>
                            <div class="info-value"><?php echo htmlspecialchars($employer['city']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Street Address</div>
                            <div class="info-value">
                                <?php echo !empty($employer['street']) ? 
                                    htmlspecialchars($employer['street']) : 'Not specified'; ?>
                            </div>
                        </div>
                        <div class="map-container">
                            <div class="map-placeholder">
                                <i class="fa fa-map-marker"></i>
                                <p>Interactive map coming soon</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Job Postings Section -->
            <div class="row">
                <div class="col-md-12">
                    <div class="info-section animate-fade-in" style="animation-delay: 0.8s;">
                        <h3><i class="fa fa-briefcase"></i> Recent Job Postings</h3>
                        <?php if (!empty($recent_jobs)): ?>
                            <?php foreach($recent_jobs as $job): ?>
                                <div class="info-item">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="info-label">Job Title</div>
                                            <div class="info-value"><?php echo htmlspecialchars($job['title']); ?></div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="info-label">Posted Date</div>
                                            <div class="info-value"><?php echo date('d M Y', strtotime($job['date_posted'])); ?></div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="info-label">Status</div>
                                            <div class="info-value">
                                                <?php 
                                                $status = strtotime($job['closing_date']) > time() ? 
                                                    '<span class="label label-success">Active</span>' : 
                                                    '<span class="label label-danger">Closed</span>';
                                                echo $status;
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="info-item">
                                <p class="text-muted">No recent job postings found.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Edit Modal -->
            <div class="modal fade" id="editEmployer<?php echo $employer['member_no']; ?>" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Edit Employer Details</h4>
                        </div>
                        <form action="app/update-employer.php" method="post">
                            <div class="modal-body">
                                <input type="hidden" name="member_no" value="<?php echo $employer['member_no']; ?>">
                                
                                <div class="form-group">
                                    <label>Company Name</label>
                                    <input type="text" class="form-control" name="company" 
                                           value="<?php echo htmlspecialchars($employer['first_name']); ?>" required>
                                </div>
                                
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="email" class="form-control" name="email" 
                                           value="<?php echo htmlspecialchars($employer['email']); ?>" required>
                                </div>
                                
                                <div class="form-group">
                                    <label>Phone</label>
                                    <input type="text" class="form-control" name="phone" 
                                           value="<?php echo htmlspecialchars($employer['phone']); ?>">
                                </div>
                                
                                <div class="form-group">
                                    <label>Country</label>
                                    <input type="text" class="form-control" name="country" 
                                           value="<?php echo htmlspecialchars($employer['country']); ?>">
                                </div>
                                
                                <div class="form-group">
                                    <label>City</label>
                                    <input type="text" class="form-control" name="city" 
                                           value="<?php echo htmlspecialchars($employer['city']); ?>">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        <?php else: ?>
            <div class="alert alert-danger">
                <strong>Error!</strong> Employer not found.
            </div>
        <?php endif; ?>
    </div>

    <script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="../js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
</body>
</html> 