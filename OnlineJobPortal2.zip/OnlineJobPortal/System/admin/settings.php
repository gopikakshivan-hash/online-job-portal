<!DOCTYPE html>
<html lang="en">
<?php 
include '../constants/settings.php';
include './constants/check-login.php';
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nightingale Jobs - Settings</title>
    <link rel="shortcut icon" href="../images/ico/favicon.png">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/admin.css" rel="stylesheet">
    <link rel="stylesheet" href="../icons/font-awesome/css/font-awesome.min.css">
    <style>
        .main-content {
            margin-left: 250px;
            padding: 20px;
            animation: fadeIn 0.5s ease-out;
        }

        .settings-section {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            animation: scaleIn 0.5s ease-out;
        }

        .settings-section h3 {
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #3498db;
        }

        .table {
            margin-bottom: 0;
        }

        .table > thead > tr > th {
            background: #f8f9fa;
            border-bottom: 2px solid #3498db;
        }

        .table > tbody > tr {
            transition: all 0.3s ease;
        }

        .table > tbody > tr:hover {
            background-color: #f8f9fa;
            transform: scale(1.01);
        }

        .btn-group .btn {
            margin-right: 5px;
        }

        .modal-content {
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
        }

        .modal-header {
            background: #2c3e50;
            color: white;
            border-radius: 10px 10px 0 0;
        }

        .modal-footer {
            border-top: none;
        }

        .form-control {
            border-radius: 5px;
            border: 1px solid #ddd;
            box-shadow: none;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: #3498db;
            box-shadow: 0 0 5px rgba(52,152,219,0.3);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes scaleIn {
            from { transform: scale(0.9); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <?php include 'constants/sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Employers Section -->
        <div class="settings-section">
            <h3><i class="fa fa-building"></i> Manage Employers</h3>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Company Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Country</th>
                            <th>City</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        require '../constants/db_config.php';
                        try {
                            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                            $stmt = $conn->prepare("SELECT * FROM tbl_users WHERE role = 'employer' ORDER BY first_name");
                            $stmt->execute();
                            $results = $stmt->fetchAll();

                            foreach($results as $row) {
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['first_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                    <td><?php echo htmlspecialchars($row['country']); ?></td>
                                    <td><?php echo htmlspecialchars($row['city']); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="app/delete-employer.php?id=<?php echo $row['member_no']; ?>" 
                                               class="btn btn-danger btn-sm" 
                                               onclick="return confirm('Are you sure you want to delete this employer?')">
                                                <i class="fa fa-trash"></i> Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php
                            }
                        } catch(PDOException $e) {
                            echo "Connection failed: " . $e->getMessage();
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Job Seekers Section -->
        <div class="settings-section">
            <h3><i class="fa fa-users"></i> Manage Job Seekers</h3>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Country</th>
                            <th>City</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        try {
                            $stmt = $conn->prepare("SELECT * FROM tbl_users WHERE role = 'employee' ORDER BY first_name");
                            $stmt->execute();
                            $results = $stmt->fetchAll();

                            foreach($results as $row) {
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                    <td><?php echo htmlspecialchars($row['country']); ?></td>
                                    <td><?php echo htmlspecialchars($row['city']); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="app/delete-jobseeker.php?id=<?php echo $row['member_no']; ?>" 
                                               class="btn btn-danger btn-sm" 
                                               onclick="return confirm('Are you sure you want to delete this job seeker?')">
                                                <i class="fa fa-trash"></i> Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php
                            }
                        } catch(PDOException $e) {
                            echo "Connection failed: " . $e->getMessage();
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Success/Error Messages -->
    <?php
    if (isset($_SESSION['success_msg'])) {
        echo '<div class="alert alert-success fade in">
                <a href="#" class="close" data-dismiss="alert">&times;</a>
                <strong>Success!</strong> ' . $_SESSION['success_msg'] . '
              </div>';
        unset($_SESSION['success_msg']);
    }
    if (isset($_SESSION['error_msg'])) {
        echo '<div class="alert alert-danger fade in">
                <a href="#" class="close" data-dismiss="alert">&times;</a>
                <strong>Error!</strong> ' . $_SESSION['error_msg'] . '
              </div>';
        unset($_SESSION['error_msg']);
    }
    ?>

    <script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="../js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
</body>
</html> 