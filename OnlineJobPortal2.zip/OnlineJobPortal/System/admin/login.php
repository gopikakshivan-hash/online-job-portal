<!DOCTYPE html>
<html lang="en">
<?php 
include '../constants/settings.php';
session_start();
if (isset($_SESSION['admin_logged']) && $_SESSION['admin_logged'] == true) {
    header("location:./");
}
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nightingale Jobs - Admin Login</title>
    <link rel="shortcut icon" href="../images/ico/favicon.png">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/auth.css" rel="stylesheet">
    <link rel="stylesheet" href="../icons/font-awesome/css/font-awesome.min.css">
</head>

<body class="not-transparent-header">
    <div class="container-wrapper">
        <div class="main-wrapper">
            <div class="auth-container">
                <div class="container">
                    <div class="auth-box">
                        <div class="auth-header">
                            <img src="../images/logo.png" alt="Logo" style="max-height: 60px; margin-bottom: 20px;">
                            <h2>Admin Login</h2>
                            <p>Please login to access admin dashboard</p>
                        </div>
                        
                        <?php
                        if(isset($_GET['r'])) {
                            if($_GET['r'] == '0') {
                                echo '<div class="alert alert-danger">Invalid Credentials</div>';
                            } else if($_GET['r'] == '1') {
                                echo '<div class="alert alert-danger">Please login to access admin panel</div>';
                            }
                        }
                        ?>
                        
                        <form class="auth-form" action="auth.php" method="POST" autocomplete="off">
                            <div class="form-group">
                                <label>Username</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                    <input type="text" class="form-control" placeholder="Enter admin username" name="username" required>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Password</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                    <input type="password" class="form-control" placeholder="Enter admin password" name="password" required>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn auth-btn">Login</button>
                            
                            <div class="auth-links">
                                <a href="../">← Back to Website</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="../js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
</body>
</html> 