<!DOCTYPE html>
<html lang="en">
<?php 
include '../constants/settings.php';
include './constants/check-login.php';

if (isset($_GET['id'])) {
    require '../constants/db_config.php';
    
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Get job seeker details
        $stmt = $conn->prepare("SELECT * FROM tbl_users WHERE member_no = :id AND role = 'employee'");
        $stmt->bindParam(':id', $_GET['id']);
        $stmt->execute();
        $jobseeker = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$jobseeker) {
            header("location:./");
            exit();
        }
        
    } catch(PDOException $e) {
        error_log("Database Error: " . $e->getMessage());
    }
} else {
    header("location:./");
    exit();
}
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Job Seeker Details - <?php echo htmlspecialchars($jobseeker['first_name']); ?></title>
    <link rel="shortcut icon" href="../images/ico/favicon.png">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/admin.css" rel="stylesheet">
    <link rel="stylesheet" href="../icons/font-awesome/css/font-awesome.min.css">
    <style>
        /* Modern Color Scheme */
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --success-color: #2ecc71;
            --warning-color: #f1c40f;
            --background-color: #f5f6fa;
            --text-color: #2c3e50;
            --sidebar-width: 250px;
        }

        body {
            background: var(--background-color);
            color: var(--text-color);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: var(--primary-color);
            color: white;
            padding: 20px 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            z-index: 1000;
            transition: all 0.3s ease;
        }

        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-menu a {
            color: white;
            padding: 15px 25px;
            display: flex;
            align-items: center;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.1);
            border-left: 3px solid var(--secondary-color);
            transform: translateX(5px);
        }

        .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            border-left: 3px solid var(--secondary-color);
        }

        .sidebar-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            min-height: 100vh;
            transition: all 0.3s ease;
        }

        /* Top Header */
        .top-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            padding: 20px 30px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
        }

        .top-header h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .top-header div {
            text-align: right;
        }

        .top-header strong {
            display: block;
            font-size: 16px;
            margin-bottom: 3px;
        }

        .top-header small {
            font-size: 13px;
            opacity: 0.8;
        }

        /* Panel Styling */
        .panel {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            border: none;
            margin-bottom: 30px;
            transition: all 0.3s ease;
        }

        .panel:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .panel-heading {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%) !important;
            border-bottom: 1px solid #dee2e6;
            padding: 15px 20px;
            border-radius: 8px 8px 0 0;
        }

        .panel-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--primary-color);
            margin: 0;
        }

        /* Profile Section */
        .profile-section {
            margin-bottom: 30px;
        }

        .profile-info {
            width: 100%;
        }

        .profile-info h3 {
            margin: 0 0 20px 0;
            color: var(--primary-color);
            font-size: 24px;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .info-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .info-item i {
            color: var(--secondary-color);
            font-size: 18px;
        }

        /* Table Styling */
        .table {
            margin-bottom: 0;
        }

        .table > thead > tr > th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: var(--primary-color);
            border-bottom: 2px solid #dee2e6;
            padding: 15px;
        }

        .table > tbody > tr {
            transition: all 0.3s ease;
        }

        .table > tbody > tr:hover {
            background-color: rgba(52, 152, 219, 0.05);
            transform: scale(1.01);
        }

        .table > tbody > tr > td {
            padding: 15px;
            vertical-align: middle;
            border-color: #f1f1f1;
        }

        /* Button Styling */
        .btn-primary {
            background: var(--secondary-color);
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .sidebar {
                margin-left: -250px;
            }
            .main-content {
                margin-left: 0;
            }
            .info-grid {
                grid-template-columns: 1fr;
            }
        }

        /* Animations */
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar slide-in">
        <div class="sidebar-header">
            <img src="../images/logo.png" alt="Logo" style="max-height: 50px;">
            <h4 style="margin-top: 15px;">Admin Dashboard</h4>
        </div>
        <div class="sidebar-menu">
            <a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
            <a href="employers.php"><i class="fa fa-building"></i> <span>Employers</span></a>
            <a href="employees.php" class="active"><i class="fa fa-users"></i> <span>Job Seekers</span></a>
            <a href="applications.php"><i class="fa fa-file-text"></i> <span>Applications</span></a>
            <a href="settings.php"><i class="fa fa-cog"></i> <span>Settings</span></a>
            <a href="logout.php"><i class="fa fa-sign-out"></i> <span>Logout</span></a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content fade-in">
        <!-- Top Header -->
        <div class="top-header">
            <h2>Job Seeker Details</h2>
            <div>
                <strong>Admin User</strong>
                <small>Administrator</small>
            </div>
        </div>

        <!-- Profile Section -->
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="profile-section">
                            <div class="profile-info">
                                <h3><?php echo htmlspecialchars($jobseeker['first_name'] . ' ' . $jobseeker['last_name']); ?></h3>
                                <div class="info-grid">
                                    <div class="info-item">
                                        <i class="fa fa-envelope"></i>
                                        <span><?php echo htmlspecialchars($jobseeker['email']); ?></span>
                                    </div>
                                    <div class="info-item">
                                        <i class="fa fa-phone"></i>
                                        <span><?php echo htmlspecialchars($jobseeker['phone']); ?></span>
                                    </div>
                                    <div class="info-item">
                                        <i class="fa fa-map-marker"></i>
                                        <span><?php echo htmlspecialchars($jobseeker['city'] . ', ' . $jobseeker['country']); ?></span>
                                    </div>
                                    <div class="info-item">
                                        <i class="fa fa-calendar"></i>
                                        <span>Joined: <?php echo date("d M Y", strtotime($jobseeker['date_registered'])); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="../js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
</body>
</html> 