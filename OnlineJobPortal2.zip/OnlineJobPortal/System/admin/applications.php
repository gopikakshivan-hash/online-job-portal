<!DOCTYPE html>
<html lang="en">
<?php 
include '../constants/settings.php';
include './constants/check-login.php';
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nightingale Jobs - Applications</title>
    <link rel="shortcut icon" href="../images/ico/favicon.png">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/admin.css" rel="stylesheet">
    <link rel="stylesheet" href="../icons/font-awesome/css/font-awesome.min.css">
    <style>
        .main-content {
            margin-left: 250px;
            padding: 20px;
            animation: fadeIn 0.5s ease-out;
        }

        .applications-section {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            animation: scaleIn 0.5s ease-out;
        }

        .applications-section h3 {
            color: #2c3e50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #3498db;
        }

        .table {
            margin-bottom: 0;
        }

        .table > thead > tr > th {
            background: #f8f9fa;
            border-bottom: 2px solid #3498db;
        }

        .table > tbody > tr {
            transition: all 0.3s ease;
        }

        .table > tbody > tr:hover {
            background-color: #f8f9fa;
            transform: scale(1.01);
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: bold;
        }

        .status-pending {
            background-color: #ffeeba;
            color: #856404;
        }

        .status-reviewed {
            background-color: #cce5ff;
            color: #004085;
        }

        .status-shortlisted {
            background-color: #d4edda;
            color: #155724;
        }

        .status-rejected {
            background-color: #f8d7da;
            color: #721c24;
        }

        .btn-group .btn {
            margin-right: 5px;
        }

        .modal-content {
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
        }

        .modal-header {
            background: #2c3e50;
            color: white;
            border-radius: 10px 10px 0 0;
        }

        .modal-footer {
            border-top: none;
        }

        .form-control {
            border-radius: 5px;
            border: 1px solid #ddd;
            box-shadow: none;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: #3498db;
            box-shadow: 0 0 5px rgba(52,152,219,0.3);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes scaleIn {
            from { transform: scale(0.9); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <?php include 'constants/sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <div class="applications-section">
            <h3><i class="fa fa-file-text"></i> Manage Applications</h3>
            
            <?php if(isset($_SESSION['success_msg'])): ?>
                <div class="alert alert-success alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <?php 
                    echo $_SESSION['success_msg'];
                    unset($_SESSION['success_msg']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['error_msg'])): ?>
                <div class="alert alert-danger alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <?php 
                    echo $_SESSION['error_msg'];
                    unset($_SESSION['error_msg']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="admin-section-title">
                <h2>Manage Applications</h2>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Job Title</th>
                            <th>Applicant</th>
                            <th>Company</th>
                            <th>Applied Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        require '../constants/db_config.php';
                        try {
                            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                            
                            // Get all applications with job and user details
                            $stmt = $conn->prepare("
                                SELECT a.*, j.title as job_title, 
                                       CONCAT(e.first_name, ' ', e.last_name) as employee_name,
                                       emp.first_name as company_name,
                                       e.email,
                                       e.phone
                                FROM tbl_job_applications a
                                JOIN tbl_jobs j ON a.job_id = j.job_id
                                JOIN tbl_users e ON a.member_no = e.member_no
                                JOIN tbl_users emp ON j.company = emp.member_no
                                ORDER BY a.application_date DESC
                            ");
                            $stmt->execute();
                            $results = $stmt->fetchAll();

                            foreach($results as $row) {
                                ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['job_title']); ?></td>
                                    <td><?php echo htmlspecialchars($row['employee_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['company_name']); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($row['application_date'])); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" 
                                                    data-target="#viewApplication<?php echo $row['id']; ?>">
                                                <i class="fa fa-eye"></i> View
                                            </button>
                                            <a href="app/delete-application.php?id=<?php echo $row['id']; ?>" 
                                               class="btn btn-danger btn-sm" 
                                               onclick="return confirm('Are you sure you want to delete this application?')">
                                                <i class="fa fa-trash"></i> Delete
                                            </a>
                                        </div>
                                    </td>
                                </tr>

                                <!-- View Application Modal -->
                                <div class="modal fade" id="viewApplication<?php echo $row['id']; ?>" tabindex="-1" role="dialog">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title">Application Details</h4>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h5>Job Details</h5>
                                                        <p><strong>Job Title:</strong> <?php echo htmlspecialchars($row['job_title']); ?></p>
                                                        <p><strong>Company:</strong> <?php echo htmlspecialchars($row['company_name']); ?></p>
                                                        <p><strong>Applied Date:</strong> <?php echo date('M d, Y', strtotime($row['application_date'])); ?></p>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <h5>Applicant Details</h5>
                                                        <p><strong>Name:</strong> <?php echo htmlspecialchars($row['employee_name']); ?></p>
                                                        <p><strong>Email:</strong> <?php echo htmlspecialchars($row['email']); ?></p>
                                                        <p><strong>Phone:</strong> <?php echo htmlspecialchars($row['phone']); ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                        } catch(PDOException $e) {
                            echo "Connection failed: " . $e->getMessage();
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="../js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
</body>
</html> 