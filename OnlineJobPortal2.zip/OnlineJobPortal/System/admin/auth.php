<?php
require '../constants/db_config.php';
session_start();

if(isset($_POST['username']) && isset($_POST['password'])) {
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $conn->prepare("SELECT * FROM tbl_admin WHERE username = :username");
        $stmt->bindParam(':username', $_POST['username']);
        $stmt->execute();
        $result = $stmt->fetchAll();
        $rec = count($result);
        
        if($rec > 0) {
            foreach($result as $row) {
                $admin_id = $row['admin_id'];
                $hashed_password = $row['password'];
                
                if(password_verify($_POST['password'], $hashed_password)) {
                    $_SESSION['admin_logged'] = true;
                    $_SESSION['admin_id'] = $admin_id;
                    header("location:./");
                } else {
                    header("location:login.php?r=0");
                }
            }
        } else {
            header("location:login.php?r=0");
        }
    } catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
    }
} else {
    header("location:login.php");
}
?> 