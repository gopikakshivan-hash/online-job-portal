<!DOCTYPE html>
<html lang="en">
<?php 
include '../constants/settings.php';
include './constants/check-login.php';

if (isset($_GET['id'])) {
    require '../constants/db_config.php';
    
    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Get employer details
        $stmt = $conn->prepare("SELECT * FROM tbl_users WHERE member_no = :id AND role = 'employer'");
        $stmt->bindParam(':id', $_GET['id']);
        $stmt->execute();
        $employer = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$employer) {
            header("location:./");
            exit();
        }
        
        // Get employer's job postings
        $stmt = $conn->prepare("SELECT * FROM tbl_jobs WHERE company = :id ORDER BY date_posted DESC");
        $stmt->bindParam(':id', $_GET['id']);
        $stmt->execute();
        $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
    }
} else {
    header("location:./");
    exit();
}
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Employer Details - <?php echo htmlspecialchars($employer['first_name']); ?></title>
    <link rel="shortcut icon" href="../images/ico/favicon.png">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/admin.css" rel="stylesheet">
    <link rel="stylesheet" href="../icons/font-awesome/css/font-awesome.min.css">
    <style>
        /* Existing styles remain here */
        .top-header {
            background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
            padding: 20px 30px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
        }

        .top-header h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .top-header div {
            text-align: right;
        }

        .top-header strong {
            display: block;
            font-size: 16px;
            margin-bottom: 3px;
        }

        .top-header small {
            font-size: 13px;
            opacity: 0.8;
        }

        .panel-heading {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%) !important;
            border-bottom: 1px solid #dee2e6;
            padding: 15px 20px;
        }

        .panel-title {
            font-size: 18px;
            font-weight: 600;
            color: #2c3e50;
            margin: 0;
        }

        .panel {
            border: none;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .panel-body {
            padding: 25px;
        }

        .table th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
        }

        .table td {
            vertical-align: middle;
        }

        .company-logo {
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .company-logo img {
            max-width: 100%;
            height: auto;
            border-radius: 4px;
        }

        /* Admin Dashboard Layout Styles */
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 250px;
            background: #2c3e50;
            padding: 20px 0;
            z-index: 1000;
            transition: all 0.3s ease;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }

        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }

        .sidebar-header h4 {
            color: #fff;
            font-size: 18px;
            font-weight: 600;
            margin: 0;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .sidebar-menu a {
            display: block;
            padding: 12px 25px;
            color: #ecf0f1;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 14px;
            border-left: 3px solid transparent;
        }

        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: #fff;
            border-left: 3px solid #3498db;
        }

        .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            color: #fff;
            border-left: 3px solid #3498db;
        }

        .sidebar-menu a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            min-height: 100vh;
            transition: all 0.3s ease;
        }

        .top-header {
            background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
            padding: 20px 30px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
        }

        .top-header h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .top-header div {
            text-align: right;
        }

        .top-header strong {
            display: block;
            font-size: 16px;
            margin-bottom: 3px;
        }

        .top-header small {
            font-size: 13px;
            opacity: 0.8;
        }

        .panel {
            background: #fff;
            border: none;
            border-radius: 8px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .panel-heading {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%) !important;
            border-bottom: 1px solid #dee2e6;
            padding: 15px 20px;
            border-radius: 8px 8px 0 0;
        }

        .panel-title {
            font-size: 18px;
            font-weight: 600;
            color: #2c3e50;
            margin: 0;
        }

        .panel-body {
            padding: 25px;
        }

        .table {
            margin-bottom: 0;
        }

        .table th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
            border-bottom: 2px solid #dee2e6;
        }

        .table td {
            vertical-align: middle;
            border-color: #f1f1f1;
        }

        .label {
            padding: 5px 10px;
            font-weight: 500;
        }

        .label-success {
            background-color: #2ecc71;
        }

        .label-danger {
            background-color: #e74c3c;
        }

        .company-logo {
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }

        .company-logo img {
            max-width: 100%;
            height: auto;
            border-radius: 4px;
        }

        @media (max-width: 768px) {
            .sidebar {
                margin-left: -250px;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <img src="../images/logo.png" alt="Logo" style="max-height: 50px;">
            <h4 style="margin-top: 15px;">Admin Dashboard</h4>
        </div>
        <div class="sidebar-menu">
            <a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a>
            <a href="employers.php" class="active"><i class="fa fa-building"></i> Employers</a>
            <a href="employees.php"><i class="fa fa-users"></i> Job Seekers</a>
            <a href="applications.php"><i class="fa fa-file-text"></i> Applications</a>
            <a href="settings.php"><i class="fa fa-cog"></i> Settings</a>
            <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <h2>Employer Details</h2>
                <div>
                    <strong>Admin User</strong>
                    <small>Administrator</small>
                </div>
        </div>

        <!-- Employer Details -->
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Company Information</h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="company-logo text-center">
                                    <?php 
                                    if (!empty($employer['avatar'])) {
                                       // echo '<img src="'.$employer['avatar'].'" alt="Company Logo" class="img-responsive">';
                                    } else {
                                       // echo '<img src="../images/default.jpg" alt="Default Logo" class="img-responsive">';
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <table class="table">
                                    <tr>
                                        <th style="width: 150px;">Company Name:</th>
                                        <td><?php echo htmlspecialchars($employer['first_name']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Email:</th>
                                        <td><?php echo htmlspecialchars($employer['email']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Phone:</th>
                                        <td><?php echo htmlspecialchars($employer['phone']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Country:</th>
                                        <td><?php echo htmlspecialchars($employer['country']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>City:</th>
                                        <td><?php echo htmlspecialchars($employer['city']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Street Address:</th>
                                        <td><?php echo htmlspecialchars($employer['street']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Date Registered:</th>
                                        <td><?php echo date("d M Y", strtotime($employer['date_registered'])); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Company Type:</th>
                                        <td><?php echo htmlspecialchars($employer['title']); ?></td> 
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Posted Jobs -->
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Posted Jobs</h3>
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Job Title</th>
                                        <th>Category</th>
                                        <th>Type</th>
                                        <th>Date Posted</th>
                                        <th>Deadline</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (count($jobs) > 0) {
                                        foreach($jobs as $job) {
                                            ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($job['title']); ?></td>
                                                <td><?php echo htmlspecialchars($job['category']); ?></td>
                                                <td><?php echo htmlspecialchars($job['type']); ?></td>
                                                <td><?php echo date("d M Y", strtotime($job['date_posted'])); ?></td>
                                                <td><?php echo htmlspecialchars($job['closing_date']); ?></td>
                                            </tr>
                                            <?php
                                        }
                                    } else {
                                        echo '<tr><td colspan="5" class="text-center">No jobs posted yet</td></tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="../js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
</body>
</html> 