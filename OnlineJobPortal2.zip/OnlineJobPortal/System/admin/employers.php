<!DOCTYPE html>
<html lang="en">
<?php 
include '../constants/settings.php';
include './constants/check-login.php';
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nightingale Jobs - Employers</title>
    <link rel="shortcut icon" href="../images/ico/favicon.png">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link href="../css/animate.css" rel="stylesheet">
    <link href="../css/admin.css" rel="stylesheet">
    <link rel="stylesheet" href="../icons/font-awesome/css/font-awesome.min.css">
    <style>
        /* Modern Color Scheme */
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --background-color: #f5f6fa;
            --text-color: #2c3e50;
            --sidebar-width: 250px;
        }

        body {
            background: var(--background-color);
            color: var(--text-color);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Enhanced Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: var(--primary-color);
            color: white;
            padding: 20px 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            z-index: 1000;
            transition: all 0.3s ease;
        }

        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-menu a {
            color: white;
            padding: 15px 25px;
            display: flex;
            align-items: center;
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.1);
            border-left: 3px solid var(--secondary-color);
            transform: translateX(5px);
        }

        .sidebar-menu a.active {
            background: rgba(255,255,255,0.1);
            border-left: 3px solid var(--secondary-color);
        }

        .sidebar-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main Content Area */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            min-height: 100vh;
            transition: all 0.3s ease;
        }

        /* Enhanced Header */
        .top-header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 10px;
            border-radius: 50px;
            background: var(--background-color);
            transition: all 0.3s ease;
        }

        .user-profile:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }

        /* Enhanced Table Styling */
        .panel {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border: none;
            margin-bottom: 30px;
            transition: all 0.3s ease;
        }

        .panel:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }

        .panel-heading {
            background: white !important;
            border-bottom: 1px solid #eee;
            padding: 20px;
            border-radius: 10px 10px 0 0;
        }

        .panel-title {
            color: var(--primary-color);
            font-size: 1.2em;
            font-weight: 600;
        }

        .table {
            margin-bottom: 0;
        }

        .table > thead > tr > th {
            border-bottom: 2px solid var(--primary-color);
            color: var(--primary-color);
            font-weight: 600;
            padding: 15px;
        }

        .table > tbody > tr {
            transition: all 0.3s ease;
        }

        .table > tbody > tr:hover {
            background-color: rgba(52, 152, 219, 0.05);
            transform: scale(1.01);
        }

        .table > tbody > tr > td {
            padding: 15px;
            vertical-align: middle;
        }

        /* Enhanced Button Styling */
        .btn-primary {
            background-color: var(--secondary-color);
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }

            .sidebar-menu span {
                display: none;
            }

            .main-content {
                margin-left: 70px;
            }

            .sidebar-header h4 {
                display: none;
            }

            .sidebar-menu a {
                padding: 15px;
                justify-content: center;
            }

            .sidebar-menu i {
                margin: 0;
            }
        }

        /* Animation Classes */
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }

        .slide-in {
            animation: slideIn 0.5s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { transform: translateX(-20px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        ::-webkit-scrollbar-thumb {
            background: var(--secondary-color);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #2980b9;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar slide-in">
        <div class="sidebar-header">
            <img src="../images/logo.png" alt="Logo" style="max-height: 50px;">
            <h4 style="margin-top: 15px;">Admin Dashboard</h4>
        </div>
        <div class="sidebar-menu">
            <a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
            <a href="employers.php" class="active"><i class="fa fa-building"></i> <span>Employers</span></a>
            <a href="employees.php"><i class="fa fa-users"></i> <span>Job Seekers</span></a>
            <a href="applications.php"><i class="fa fa-file-text"></i> <span>Applications</span></a>
            <a href="settings.php"><i class="fa fa-cog"></i> <span>Settings</span></a>
            <a href="logout.php"><i class="fa fa-sign-out"></i> <span>Logout</span></a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content fade-in">
        <!-- Top Header -->
        <div class="top-header">
            <h2>Employers List</h2>
            <div class="user-profile">
                <img src="../images/admin.jpg" alt="Admin">
                <div>
                    <strong>Admin User</strong>
                    <small>Administrator</small>
                </div>
            </div>
        </div>

        <!-- Employers List -->
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">All Employers</h3>
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Company Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>City</th>
                                        <th>Country</th>
                                        <th>Date Registered</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    require '../constants/db_config.php';
                                    try {
                                        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                                        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                        $stmt = $conn->prepare("SELECT * FROM tbl_users WHERE role = 'employer' ORDER BY first_name");
                                        $stmt->execute();
                                        $result = $stmt->fetchAll();

                                        foreach($result as $row) {
                                            ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($row['first_name']); ?></td>
                                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                                <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                                <td><?php echo htmlspecialchars($row['city']); ?></td>
                                                <td><?php echo htmlspecialchars($row['country']); ?></td>
                                                <td><?php echo date("d M Y", strtotime($row['date_registered'])); ?></td>
                                                <td>
                                                    <a href="employer-detail.php?id=<?php echo $row['member_no']; ?>" 
                                                       class="btn btn-primary btn-sm">
                                                        <i class="fa fa-eye"></i> View Details
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    } catch(PDOException $e) {
                                        echo "Connection failed: " . $e->getMessage();
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="../js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="../bootstrap/js/bootstrap.min.js"></script>
</body>
</html> 