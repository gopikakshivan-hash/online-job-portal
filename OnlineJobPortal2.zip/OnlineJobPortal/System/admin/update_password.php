<?php
require '../constants/db_config.php';

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // New password
    $new_password = "admin123";
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Update admin password
    $stmt = $conn->prepare("UPDATE tbl_admin SET password = :password WHERE username = 'admin'");
    $stmt->bindParam(':password', $hashed_password);
    $stmt->execute();

} catch(PDOException $e) {
    echo "Error updating password: " . $e->getMessage();
}
?> 