<?php
include 'check_reply.php';
?>

<form name="frm" class="auth-form" action="app/create-account.php" method="POST" autocomplete="off">
    <div class="form-group">
        <label>Company Name</label>
        <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-building"></i></span>
            <input class="form-control" placeholder="Enter your company name" name="company" required type="text">
        </div>
    </div>

    <div class="form-group">
        <label>Company Type</label>
        <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-briefcase"></i></span>
            <input class="form-control" placeholder="Eg: Booking/Travel, Computer Software etc" name="type" required type="text">
        </div>
    </div>

    <div class="form-group">
        <label>Email Address</label>
        <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
            <input class="form-control" placeholder="Enter your email address" name="email" required type="email">
        </div>
    </div>

    <div class="form-group">
        <label>Password</label>
        <div class="input-group password-field">
            <span class="input-group-addon"><i class="fa fa-lock"></i></span>
            <input type="password" class="form-control" name="password" id="employer_reg_password" placeholder="Min 8 and Max 20 characters" required>
            <span class="password-toggle" onclick="togglePassword('employer_reg_password', 'employer_reg_password_icon')">
                <i class="fa fa-eye" id="employer_reg_password_icon"></i>
            </span>
        </div>
        <small class="form-text text-muted">Password must be between 8-20 characters</small>
    </div>

    <div class="form-group">
        <label>Password Confirmation</label>
        <div class="input-group password-field">
            <span class="input-group-addon"><i class="fa fa-lock"></i></span>
            <input type="password" class="form-control" name="confirmpassword" id="employer_reg_confirm_password" placeholder="Re-type password again" required>
            <span class="password-toggle" onclick="togglePassword('employer_reg_confirm_password', 'employer_reg_confirm_password_icon')">
                <i class="fa fa-eye" id="employer_reg_confirm_password_icon"></i>
            </span>
        </div>
    </div>

    <input type="hidden" name="acctype" value="102">

    <button onclick="return val();" type="submit" name="reg_mode" class="btn auth-btn">
        Create Company Account
    </button>
</form>

<script>
function val(){
if(frm.password.value == "")
{
    alert("Enter the Password.");
    frm.password.focus(); 
    return false;
}
if((frm.password.value).length < 8)
{
    alert("Password should be minimum 8 characters.");
    frm.password.focus();
    return false;
}

if((frm.password.value).length > 20)
{
    alert("Password should be maximum 20 characters.");
    frm.password.focus();
    return false;
}

if(frm.confirmpassword.value == "")
{
    alert("Enter the Confirmation Password.");
    return false;
}
if(frm.confirmpassword.value != frm.password.value)
{
    alert("Password confirmation does not match.");
    return false;
}

return true;
}
</script>