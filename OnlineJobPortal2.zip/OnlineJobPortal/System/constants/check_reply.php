<?php
require 'constants/db_config.php';
if (isset($_GET['r'])) {
    $error_code = $_GET['r'];
    $message = '';
    $type = 'danger';

    // Map error codes to messages
    switch($error_code) {
        case "0346":
            $message = "Invalid email or password";
            $type = 'danger';
            break;
        case "role_mismatch":
            $message = "Please use the correct login section for your account type";
            break;
        case "invalid":
            $message = "Invalid credentials";
            break;
        case "error":
            $message = "An error occurred. Please try again";
            break;
        case "success":
            $message = "You have been registered successfully!";
            $type = 'success';
            break;
        default:
            // Check database for custom messages
            try {
                $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                $stmt = $conn->prepare("SELECT * FROM tbl_alerts WHERE code = :errorcode");
                $stmt->bindParam(':errorcode', $error_code);
                $stmt->execute();
                $result = $stmt->fetchAll();

                if (count($result) > 0) {
                    foreach($result as $row) {
                        $message = $row['description'];
                        $type = $row['type'];
                    }
                }
            } catch(PDOException $e) {
                $message = "An error occurred";
            }
    }

    if ($message) {
        echo '<div class="alert alert-'.$type.' auto-dismiss" role="alert">'.$message.'</div>';
        if ($type === 'success') {
            echo '<div class="alert alert-info auto-dismiss" role="alert" style="margin-top: 10px;">Please login to access your account</div>';
            // Add auto-redirect script
            echo '<script>
                setTimeout(function() {
                    window.location.href = "login.php";
                }, 3000);
            </script>';
        }
    }
}

?>