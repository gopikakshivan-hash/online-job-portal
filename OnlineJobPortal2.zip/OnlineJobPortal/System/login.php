<!doctype html>
<html lang="en">
<?php 
include 'constants/settings.php'; 
include 'constants/check-login.php';
?>
<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Nightingale Jobs - Login</title>
	
	<meta name="description" content="Online Job Management / Job Portal" />
	<meta name="keywords" content="job, work, resume, applicants, application, employee, employer, hire, hiring, human resource management, hr, online job management, company, worker, career, recruiting, recruitment" />
	<meta name="author" content="BwireSoft">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta property="og:image" content="http://<?php echo "$actual_link"; ?>/images/banner.jpg" />
    <meta property="og:image:secure_url" content="https://<?php echo "$actual_link"; ?>/images/banner.jpg" />
    <meta property="og:image:type" content="image/jpeg" />
    <meta property="og:image:width" content="500" />
    <meta property="og:image:height" content="300" />
    <meta property="og:image:alt" content="Nightingale Jobs" />
    <meta property="og:description" content="Online Job Management / Job Portal" />

	<link rel="shortcut icon" href="images/ico/favicon.png">

	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" media="screen">	
	<link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/component.css" rel="stylesheet">
	<link href="css/auth.css" rel="stylesheet">
	
	<link rel="stylesheet" href="icons/linearicons/style.css">
	<link rel="stylesheet" href="icons/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="icons/simple-line-icons/css/simple-line-icons.css">
	<link rel="stylesheet" href="icons/ionicons/css/ionicons.css">
	<link rel="stylesheet" href="icons/pe-icon-7-stroke/css/pe-icon-7-stroke.css">
	<link rel="stylesheet" href="icons/rivolicons/style.css">
	<link rel="stylesheet" href="icons/flaticon-line-icon-set/flaticon-line-icon-set.css">
	<link rel="stylesheet" href="icons/flaticon-streamline-outline/flaticon-streamline-outline.css">
	<link rel="stylesheet" href="icons/flaticon-thick-icons/flaticon-thick.css">
	<link rel="stylesheet" href="icons/flaticon-ventures/flaticon-ventures.css">

	<link href="css/style.css" rel="stylesheet">
 <script type="text/javascript">
   function update(str)
   {

	if(document.getElementById('mymail').value == "")
   {
	alert("Please enter your email");

    }else{
		  document.getElementById("data").innerHTML = "Please wait...";
      var xmlhttp;

      if (window.XMLHttpRequest)
      {
        xmlhttp=new XMLHttpRequest();
      }
      else
      {
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
      }	

      xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
          document.getElementById("data").innerHTML = xmlhttp.responseText;
        }
      }

      xmlhttp.open("GET","app/reset-pw.php?opt="+str, true);
      xmlhttp.send();
}

  }
  
   function reset_text()
   {  
   document.getElementById('mymail').value = "";
   document.getElementById("data").innerHTML = "";
   }

</script>

<style>
.alert.auto-dismiss {
    position: relative;
    width: 100%;
    text-align: center;
    margin: 0;
    padding: 15px 30px;
    border-radius: 0;
    animation: slideDown 0.5s ease-out, fadeOut 0.5s ease-out 2.5s;
    border: none;
}

.alert.auto-dismiss.alert-danger {
    background-color: #dc3545;
    color: white;
}

.alert.auto-dismiss.alert-success {
    background-color: #28a745;
    color: white;
}

.alert.auto-dismiss.alert-info {
    background-color: #17a2b8;
    color: white;
}

.alert-container {
    width: 100%;
    position: relative;
    overflow: hidden;
}

@keyframes slideDown {
    0% {
        transform: translateY(-100%);
    }
    100% {
        transform: translateY(0);
    }
}

@keyframes fadeOut {
    0% {
        opacity: 1;
    }
    100% {
        opacity: 0;
    }
}

/* Add spacing between alerts */
.alert-container .alert + .alert {
    margin-top: 10px;
}

.password-field {
    position: relative;
}

.password-toggle {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    color: #666;
    z-index: 10;
}

.password-toggle:hover {
    color: #333;
}

.password-toggle i {
    font-size: 16px;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto dismiss alerts after 3 seconds
    var alerts = document.querySelectorAll('.alert.auto-dismiss');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            alert.style.display = 'none';
        }, 3000);
    });
});

function togglePassword(inputId, iconId) {
    var passwordInput = document.getElementById(inputId);
    var icon = document.getElementById(iconId);
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>
</head>


<body class="not-transparent-header">

	<div class="container-wrapper">


		<header id="header">


			<nav class="navbar navbar-default navbar-fixed-top navbar-sticky-function">

				<div class="container">
					
					<div class="logo-wrapper">
						<div class="logo">
							<a href="./"><img src="images/logo.png" alt="Logo" /></a>
						</div>
					</div>
					
					<div id="navbar" class="navbar-nav-wrapper navbar-arrow">
					
						<ul class="nav navbar-nav" id="responsive-menu">
						
							<li>
							
								<a href="./">Home</a>
								
							</li>
							
							<li>
								<a href="job-list.php">Job List</a>

							</li>
							
							<li>
								<a href="employers.php">Employers</a>
							</li>
							
							<li>
								<a href="employees.php">Employees</a>
							</li>
							
							<li>
								<a href="contact.php">Contact Us</a>
							</li>

						</ul>
				
					</div>

					<div class="nav-mini-wrapper">
						<ul class="nav-mini sign-in">
							<li><a  href="login.php">login</a></li>
							<li><a data-toggle="modal" href="#registerModal">register</a></li>
						</ul>
					</div>
				
				</div>
				
				<div id="slicknav-mobile"></div>
				
			</nav>
	
			<div id="registerModal" class="modal fade login-box-wrapper" tabindex="-1" style="display: none;" data-backdrop="static" data-keyboard="false" data-replace="true">
			
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title text-center">Create your account for free</h4>
				</div>
				
				<div class="modal-body">
				
					<div class="row gap-20">
					
						<div class="col-sm-6 col-md-6">
							<a href="register.php?p=Employer" class="btn btn-facebook btn-block mb-5-xs">Register as Employer</a>
						</div>
						<div class="col-sm-6 col-md-6">
							<a href="register.php?p=Employee" class="btn btn-facebook btn-block mb-5-xs">Register as Employee</a>
						</div>

					</div>
				
				</div>
				
				<div class="modal-footer text-center">
					<button type="button" data-dismiss="modal" class="btn btn-primary btn-inverse">Close</button>
				</div>
				
			</div>



			
		</header>


		<div class="main-wrapper">


			<div class="breadcrumb-wrapper">
			
				<div class="container">
				
					<ol class="breadcrumb-list">
						<li><a href="./">Home</a></li>
						<li><span>Access your account</span></li>
					</ol>
					
				</div>
				
			</div>

            <div class="alert-container">
                <?php include 'constants/check_reply.php'; ?>
            </div>

			<div class="auth-container">	
	
				<div class="container">
				
					<div class="row">
					
						<div class="col-md-10 col-md-offset-1">
						
							<div class="row">

								<div class="col-sm-6 col-sm-offset-3">
                                <div class="auth-box">
							
                                <div class="auth-header">
                                <h2>Welcome Back!</h2>
                                <p>Please login to access your account</p>
                                </div>

                                <div class="auth-body">
																
                                <div class="login-tabs">
                                    <ul class="nav nav-tabs">
                                        <li class="active"><a href="#employee" data-toggle="tab"><i class="fa fa-user"></i> Employee</a></li>
                                        <li><a href="#employer" data-toggle="tab"><i class="fa fa-building"></i> Employer</a></li>
                                        <li><a href="#admin" data-toggle="tab"><i class="fa fa-lock"></i> Admin</a></li>
                                    </ul>

                                    <div class="tab-content">
                                        <!-- Employee Login -->
                                        <div class="tab-pane fade in active" id="employee">
                                            <form class="auth-form" action="app/auth.php?emp=1" method="POST" autocomplete="off">
                                                <div class="form-group">
                                                    <label>Email</label>
                                                    <div class="input-group">
                                                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                                        <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label>Password</label>
                                                    <div class="input-group password-field">
                                                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                                        <input type="password" class="form-control" name="password" id="employee_password" placeholder="Enter your password" required>
                                                        <span class="password-toggle" onclick="togglePassword('employee_password', 'employee_password_icon')">
                                                            <i class="fa fa-eye" id="employee_password_icon"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                                
                                                <button type="submit" class="btn auth-btn">Login as Employee</button>
                                            </form>
                                        </div>

                                        <!-- Employer Login -->
                                        <div class="tab-pane fade" id="employer">
                                            <form class="auth-form" action="app/auth.php?emp=2" method="POST" autocomplete="off">
                                                <div class="form-group">
                                                    <label>Email</label>
                                                    <div class="input-group">
                                                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                                        <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label>Password</label>
                                                    <div class="input-group password-field">
                                                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                                        <input type="password" class="form-control" name="password" id="employer_password" placeholder="Enter your password" required>
                                                        <span class="password-toggle" onclick="togglePassword('employer_password', 'employer_password_icon')">
                                                            <i class="fa fa-eye" id="employer_password_icon"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                                
                                                <button type="submit" class="btn auth-btn">Login as Employer</button>
                                            </form>
                                        </div>

                                        <!-- Admin Login -->
                                        <div class="tab-pane fade" id="admin">
                                            <form class="auth-form" action="admin/app/auth.php" method="POST" autocomplete="off">
                                                <div class="form-group">
                                                    <label>Username</label>
                                                    <div class="input-group">
                                                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                                        <input type="text" class="form-control" name="username" placeholder="Enter admin username" required>
                                                    </div>
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label>Password</label>
                                                    <div class="input-group password-field">
                                                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                                        <input type="password" class="form-control" name="password" id="admin_password" placeholder="Enter admin password" required>
                                                        <span class="password-toggle" onclick="togglePassword('admin_password', 'admin_password_icon')">
                                                            <i class="fa fa-eye" id="admin_password_icon"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                                
                                                <button type="submit" class="btn auth-btn">Login as Admin</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <div class="auth-separator">
                                    <span>or</span>
                                </div>

                                <div class="auth-links">
                                    Don't have an account? <a data-toggle="modal" href="#registerModal">Register now</a>
                                    <br>
                                    <a href="forgot-password.php">Forgot your password?</a>
                                </div>
</div>

</div>

</div>
							
						</div>
						
					</div>
					
				</div>
			
			</div>
			
			<footer class="footer-wrapper">
			
				<div class="main-footer">
				
					<div class="container">
					
						<div class="row">
						
							<div class="col-sm-12 col-md-9">
							
								<div class="row">
								
									<div class="col-sm-6 col-md-4">
									
										<div class="footer-about-us">
											<h5 class="footer-title">About Nightingale Jobs</h5>
											<p>Nightingale Jobs is a job portal, online job management system developed by Junaid M for the project in march 2025.</p>
										
										</div>

									</div>
									
									<div class="col-sm-6 col-md-5 mt-30-xs">
										<h5 class="footer-title">Quick Links</h5>
										<ul class="footer-menu clearfix">
											<li><a href="./">Home</a></li>
											<li><a href="job-list.php">Job List</a></li>
											<li><a href="employers.php">Employers</a></li>
											<li><a href="employees.php">Employees</a></li>
											<li><a href="contact.php">Contact Us</a></li>
											<li><a href="#">Go to top</a></li>

										</ul>
									
									</div>

								</div>

							</div>
							
							<div class="col-sm-12 col-md-3 mt-30-sm">
							
								<h5 class="footer-title">Nightingale Jobs Contact</h5>
								
								<p>Address : Kasaragod, Povval Junction Pincode 671541</p>
								<p>Email : <a href="mailto:nightingale.jobportal@gmail.com">nightingale.jobportal@gmail.com</a></p>
								<p>Phone : <a href="tel:+918590958329">+91 85909 58329</a></p>
								

							</div>

							
						</div>
						
					</div>
					
				</div>
				
				<div class="bottom-footer">
				
					<div class="container">
					
						<div class="row">
						
							<div class="col-sm-4 col-md-4">
					
								<p class="copy-right">&#169; Copyright <?php echo date('Y'); ?> Nightingale Vision Software</p>
								
							</div>
							
							<div class="col-sm-4 col-md-4">
							
								<ul class="bottom-footer-menu">
									<li><a >Developed by Junaid M</a></li>
								</ul>
							
							</div>
							
							<div class="col-sm-4 col-md-4">
								<ul class="bottom-footer-menu for-social">
									<li><a href="<?php echo "$tw"; ?>"><i class="ri ri-twitter" data-toggle="tooltip" data-placement="top" title="twitter"></i></a></li>
									<li><a href="<?php echo "$fb"; ?>"><i class="ri ri-facebook" data-toggle="tooltip" data-placement="top" title="facebook"></i></a></li>
									<li><a href="<?php echo "$ig"; ?>"><i class="ri ri-instagram" data-toggle="tooltip" data-placement="top" title="instagram"></i></a></li>
								</ul>
							</div>
						
						</div>

					</div>
					
				</div>
			
			</footer>
			
		</div>


	</div> 


<div id="back-to-top">
   <a href="#"><i class="ion-ios-arrow-up"></i></a>
</div>

<script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-modalmanager.js"></script>
<script type="text/javascript" src="js/bootstrap-modal.js"></script>
<script type="text/javascript" src="js/smoothscroll.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.waypoints.min.js"></script>
<script type="text/javascript" src="js/wow.min.js"></script>
<script type="text/javascript" src="js/jquery.slicknav.min.js"></script>
<script type="text/javascript" src="js/jquery.placeholder.min.js"></script>
<script type="text/javascript" src="js/bootstrap-tokenfield.js"></script>
<script type="text/javascript" src="js/typeahead.bundle.min.js"></script>
<script type="text/javascript" src="js/bootstrap3-wysihtml5.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="js/jquery-filestyle.min.js"></script>
<script type="text/javascript" src="js/bootstrap-select.js"></script>
<script type="text/javascript" src="js/ion.rangeSlider.min.js"></script>
<script type="text/javascript" src="js/handlebars.min.js"></script>
<script type="text/javascript" src="js/jquery.countimator.js"></script>
<script type="text/javascript" src="js/jquery.countimator.wheel.js"></script>
<script type="text/javascript" src="js/slick.min.js"></script>
<script type="text/javascript" src="js/easy-ticker.js"></script>
<script type="text/javascript" src="js/jquery.introLoader.min.js"></script>
<script type="text/javascript" src="js/jquery.responsivegrid.js"></script>
<script type="text/javascript" src="js/customs.js"></script>


</body>

</html>